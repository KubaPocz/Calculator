﻿using System.Windows;
using System.Windows.Input;

namespace Kalkulator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (mainBlock.Text.Length <= 12)
            {
                switch (e.Key)
                {
                    case Key.D1:
                        {
                            dig_1_Click(sender, e);
                            break;
                        }
                    case Key.D2:
                        {
                            dig_2_Click(sender, e); break;
                        }
                    case Key.D3:
                        {
                            dig_3_Click(sender, e); break;
                        }
                    case Key.D4:
                        {
                            dig_4_Click(sender, e); break;
                        }
                    case Key.D5:
                        {
                            dig_5_Click(sender, e); break;
                        }
                    case Key.D6:
                        {
                            dig_6_Click(sender, e); break;
                        }
                    case Key.D7:
                        {
                            dig_7_Click(sender, e); break;
                        }
                    case Key.D8:
                        {
                            dig_8_Click(sender, e); break;
                        }
                    case Key.D9:
                        {
                            dig_9_Click(sender, e); break;
                        }
                    case Key.D0:
                        {
                            dig_0_Click(sender, e); break;
                        }
                    case Key.Decimal:
                        {
                            dig_dot_Click(sender, e); break;
                        }
                    case Key.OemPeriod:
                        {
                            dig_dot_Click(sender, e); break;
                        }
                    case Key.Enter:
                        {
                            ope_result_Click(sender, e); break;
                        }
                }
            }
        }

        private void ope_percent_Click(object sender, RoutedEventArgs e)
        {
            mainBlock.Text = Convert.ToString(Convert.ToDouble(mainBlock.Text) * 0.01);
        }

        private void fun_clearLast_Click(object sender, RoutedEventArgs e)
        {
            mainBlock.Text = "0";
        }

        private void fun_clearAll_Click(object sender, RoutedEventArgs e)
        {
            topBlock.Text = null;
            mainBlock.Text = "0";
        }

        private void fun_clearOne_Click(object sender, RoutedEventArgs e)
        {
            if (mainBlock.Text.Contains("Nie można dzielić przez zero!") || mainBlock.Text.Contains("Za duża liczba!"))
            {
                mainBlock.Text = null;
            }
            else if (mainBlock.Text.Length > 0 && mainBlock.Text.Length != 1 && mainBlock.Text[0] != 0)
            {
                mainBlock.Text = mainBlock.Text.Substring(0, mainBlock.Text.Length - 1);
            }
        }

        private void ope_inversion_Click(object sender, RoutedEventArgs e)
        {
            if (mainBlock.Text == "0")
                mainBlock.Text = "Nie można dzielić przez zero!";
            else
                mainBlock.Text = Convert.ToString(1.0f / Convert.ToDouble(mainBlock.Text));
        }

        private void ope_power_Click(object sender, RoutedEventArgs e)
        {
            if (double.TryParse(mainBlock.Text, out double power))
            {
                string result = Convert.ToString(Math.Pow(power, 2));
                if (result.Length > 13)
                {
                    if (result.Contains(","))
                        mainBlock.Text = result.Substring(0, 13);
                    else
                        mainBlock.Text = "Za duża liczba!";
                }
                else
                    mainBlock.Text = result;

            }
            else if (mainBlock.Text.Contains("Nie można dzielić przez zero!") || mainBlock.Text.Contains("Za duża liczba!")) { }
            else
                mainBlock.Text = "0";

        }

        private void ope_root_Click(object sender, RoutedEventArgs e)
        {
            if (double.TryParse(mainBlock.Text, out double power))
            {
                string result = Convert.ToString(Math.Sqrt(Convert.ToDouble(mainBlock.Text)));
                if (result.Length > 13)
                {
                    mainBlock.Text = result.Substring(0, 13);
                }
                else
                    mainBlock.Text = result;
            }
        }

        private void ope_division_Click(object sender, RoutedEventArgs e)
        {
            topBlock.Text = mainBlock.Text + "÷";
            mainBlock.Text = "0";
        }

        private void dig_7_Click(object sender, RoutedEventArgs e)
        {
            ClearFirst();
            if (mainBlock.Text.Length < 13)
                mainBlock.Text += "7";
        }

        private void dig_8_Click(object sender, RoutedEventArgs e)
        {
            ClearFirst();
            if (mainBlock.Text.Length < 13)
                mainBlock.Text += "8";
        }

        private void dig_9_Click(object sender, RoutedEventArgs e)
        {
            ClearFirst();
            if (mainBlock.Text.Length < 13)
                mainBlock.Text += "9";
        }

        private void ope_multiplication_Click(object sender, RoutedEventArgs e)
        {
            topBlock.Text = mainBlock.Text + "×";
            mainBlock.Text = "0";
        }

        private void dig_4_Click(object sender, RoutedEventArgs e)
        {
            ClearFirst();
            if (mainBlock.Text.Length < 13)
                mainBlock.Text += "4";
        }

        private void dig_5_Click(object sender, RoutedEventArgs e)
        {
            ClearFirst();
            if (mainBlock.Text.Length < 13)
                mainBlock.Text += "5";
        }

        private void dig_6_Click(object sender, RoutedEventArgs e)
        {
            ClearFirst();
            if (mainBlock.Text.Length < 13)
                mainBlock.Text += "6";
        }

        private void ope_substraction_Click(object sender, RoutedEventArgs e)
        {
            topBlock.Text = mainBlock.Text + "−";
            mainBlock.Text = "0";
        }

        private void dig_3_Click(object sender, RoutedEventArgs e)
        {
            ClearFirst();
            if (mainBlock.Text.Length < 13)
                mainBlock.Text += "3";
        }

        private void dig_2_Click(object sender, RoutedEventArgs e)
        {
            ClearFirst();
            if (mainBlock.Text.Length < 13)
                mainBlock.Text += "2";
        }

        private void dig_1_Click(object sender, RoutedEventArgs e)
        {
            ClearFirst();
            if (mainBlock.Text.Length < 13)
                mainBlock.Text += "1";
        }

        private void ope_addition_Click(object sender, RoutedEventArgs e)
        {
            topBlock.Text = mainBlock.Text + "+";
            mainBlock.Text = "0";
        }

        private void ope_negation_Click(object sender, RoutedEventArgs e)
        {
            mainBlock.Text = Convert.ToString(Convert.ToDouble(mainBlock.Text) * -1);
        }

        private void dig_0_Click(object sender, RoutedEventArgs e)
        {
            if (mainBlock.Text.Length < 13)
            {
                if (mainBlock.Text.Length == 1)
                {
                    if (mainBlock.Text[0] != '0')
                        mainBlock.Text += "0";
                }
                else
                {
                    mainBlock.Text += "0";
                }
            }
        }

        private void dig_dot_Click(object sender, RoutedEventArgs e)
        {
            if (!mainBlock.Text.Contains(","))
            {
                if (mainBlock.Text.Length > 0)
                {
                    if (mainBlock.Text[mainBlock.Text.Length - 1] != ',')
                        mainBlock.Text += ",";
                }
                else if (mainBlock.Text.Length == 0)
                {
                    mainBlock.Text = "0,";
                }
            }
        }

        private void ope_result_Click(object sender, RoutedEventArgs e)
        {
            if (mainBlock.Text.Length == 0)
                mainBlock.Text = "0";
            double firstNumber;
            if (mainBlock.Text.Length > 0)
            {
                firstNumber = Convert.ToDouble(topBlock.Text.Substring(0, topBlock.Text.Length - 1));
            }
            else
            {
                firstNumber = 0;
            }
            double secondNumber = Convert.ToDouble(mainBlock.Text);
            string result = "0";

            if (topBlock.Text.Contains("÷"))
            {
                if (secondNumber == 0)
                    result = "Nie można dzielić przez zero!";
                else
                    result = Convert.ToString(firstNumber / secondNumber);
                topBlock.Text = null;
            }
            else if (topBlock.Text.Contains("×"))
            {
                result = Convert.ToString(firstNumber * secondNumber);
                topBlock.Text = null;
            }
            else if (topBlock.Text.Contains("−"))
            {
                result = Convert.ToString(firstNumber - secondNumber);
                topBlock.Text = null;
            }
            else if (topBlock.Text.Contains("+"))
            {
                result = Convert.ToString(firstNumber + secondNumber);
                topBlock.Text = null;
            }
            if (result.Length > 13 && !result.Contains("Nie można dzielić przez zero!"))
                mainBlock.Text = result.Substring(0, 13);
            else
                mainBlock.Text = result;
        }

        private void ClearFirst()
        {
            if (mainBlock.Text.Length == 1 && mainBlock.Text[0] == '0')
            {
                mainBlock.Text = null;
            }
            else if (mainBlock.Text.Contains("Nie można dzielić przez zero!") || mainBlock.Text.Contains("Za duża liczba!"))
            {
                mainBlock.Text = null;
            }
        }

    }
}